# دليل بناء ملف APK - تطبيق إدارة المخزون

## المتطلبات الأساسية

قبل البدء، تأكد من تثبيت الأدوات التالية على جهازك:

### 1. Java Development Kit (JDK)
- تحميل: https://www.oracle.com/java/technologies/javase-jdk11-downloads.html
- الإصدار الموصى به: JDK 11 أو أحدث

### 2. Android Studio
- تحميل: https://developer.android.com/studio
- يتضمن Android SDK و Gradle تلقائيًا

### 3. Node.js و pnpm
- تحميل Node.js: https://nodejs.org/
- تثبيت pnpm: `npm install -g pnpm`

## خطوات البناء

### الخطوة 1: استخراج ملفات المشروع
```bash
# انسخ مجلد المشروع إلى جهازك
cd /path/to/inventory_manager_app
```

### الخطوة 2: تثبيت المتطلبات
```bash
# تثبيت جميع المتطلبات
pnpm install
```

### الخطوة 3: بناء التطبيق الويب
```bash
# بناء نسخة الإنتاج
pnpm build
```

### الخطوة 4: نسخ الملفات إلى مشروع Android
```bash
# تحديث ملفات الويب في مشروع Android
npx cap sync android
```

### الخطوة 5: فتح المشروع في Android Studio
```bash
# فتح مشروع Android في Android Studio
# اختر: File > Open > اختر مجلد "android"
```

### الخطوة 6: بناء ملف APK
في Android Studio:
1. اذهب إلى: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
2. انتظر انتهاء البناء (قد يستغرق عدة دقائق)
3. سيظهر إشعار بموقع ملف APK

### الخطوة 7: تثبيت التطبيق على الهاتف
```bash
# استخدم adb لتثبيت APK على جهاز متصل
adb install -r app-debug.apk

# أو انقل الملف يدويًا إلى الهاتف وثبته
```

## معلومات المشروع

- **معرف التطبيق:** com.inventorymanager.app
- **اسم التطبيق:** تطبيق إدارة المخزون
- **الإصدار:** 1.0.0

## حل المشاكل الشائعة

### المشكلة: "Java not found"
**الحل:** تأكد من تثبيت JDK وإضافته إلى متغيرات البيئة

### المشكلة: "Android SDK not found"
**الحل:** 
1. افتح Android Studio
2. اذهب إلى: Tools > SDK Manager
3. تأكد من تثبيت Android SDK Platform (API Level 33+)

### المشكلة: "Gradle build failed"
**الحل:**
1. حذف مجلد `.gradle` و `build`
2. قم بتشغيل: `./gradlew clean build`

## ملاحظات مهمة

- التطبيق يتطلب Android 7.0 (API 24) أو أحدث
- تأكد من توصيل جهاز Android بالكمبيوتر عبر USB
- فعّل "USB Debugging" على الهاتف

## الدعم والمساعدة

للمزيد من المعلومات:
- Capacitor Docs: https://capacitorjs.com/docs
- Android Studio Docs: https://developer.android.com/docs
- Gradle Docs: https://gradle.org/

