# دليل نشر التطبيق على خادم مجاني

## الخيار 1: استخدام Netlify (الأسهل - بدون حساب GitHub)

### الخطوات:

1. **اذهب إلى:** https://app.netlify.com/drop

2. **اسحب مجلد `dist` من المشروع** إلى الصفحة

3. **انتظر قليلاً** حتى ينتهي التحميل

4. **سيظهر رابط عام** مثل:
   ```
   https://xxxxx.netlify.app
   ```

5. **أرسل هذا الرابط لصديقك!** ✅

---

## الخيار 2: استخدام Vercel (أفضل للمستقبل)

### الخطوات:

1. **اذهب إلى:** https://vercel.com/new

2. **اختر "Import Git Repository"**

3. **ألصق رابط GitHub للمشروع** (إذا كان لديك)

4. **أو اختر "Deploy without Git"** واسحب مجلد `dist`

5. **سيظهر رابط عام** للتطبيق

---

## الخيار 3: استخدام GitHub Pages (مجاني تماماً)

### الخطوات:

1. **أنشئ حساب GitHub** (مجاني): https://github.com/signup

2. **أنشئ مستودع جديد** باسم `inventory-manager`

3. **رفع مجلد `dist` إلى المستودع**

4. **اذهب إلى Settings > Pages**

5. **اختر "Deploy from a branch"**

6. **اختر `main` branch و `dist` folder**

7. **سيظهر رابط عام** مثل:
   ```
   https://yourusername.github.io/inventory-manager
   ```

---

## الخيار 4: استخدام Surge.sh (الأسرع)

### الخطوات:

1. **ثبّت Surge:**
   ```bash
   npm install -g surge
   ```

2. **انشر التطبيق:**
   ```bash
   surge dist
   ```

3. **اتبع التعليمات على الشاشة**

4. **سيظهر رابط عام** للتطبيق

---

## الخيار 5: استخدام Firebase Hosting

### الخطوات:

1. **اذهب إلى:** https://firebase.google.com

2. **أنشئ مشروع جديد**

3. **ثبّت Firebase CLI:**
   ```bash
   npm install -g firebase-tools
   ```

4. **انشر التطبيق:**
   ```bash
   firebase init hosting
   firebase deploy
   ```

5. **سيظهر رابط عام** للتطبيق

---

## التوصية:

**استخدم Netlify** - إنه الأسهل والأسرع! 🚀

فقط اسحب مجلد `dist` وسيتم النشر تلقائياً!

