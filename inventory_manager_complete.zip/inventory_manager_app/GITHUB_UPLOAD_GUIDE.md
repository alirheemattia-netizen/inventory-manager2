# دليل رفع المشروع على GitHub

## الطريقة الأسهل - استخدام GitHub Desktop

### الخطوة 1: تحميل GitHub Desktop
- اذهب إلى: https://desktop.github.com
- حمّل البرنامج المناسب لجهازك
- ثبّته

### الخطوة 2: تسجيل الدخول
- افتح GitHub Desktop
- اختر "Sign in to GitHub.com"
- استخدم حسابك: `alirheemattia-netizen`

### الخطوة 3: إنشاء مستودع جديد
1. اضغط على "File" → "New Repository"
2. أدخل الاسم: `inventory-manager`
3. اختر المجلد: `/home/ubuntu/inventory_manager_app`
4. اضغط "Create Repository"

### الخطوة 4: رفع المشروع
1. اكتب رسالة الـ Commit: "Initial commit: Inventory Management App"
2. اضغط "Commit to main"
3. اضغط "Publish repository"
4. تأكد أنه "Public"
5. اضغط "Publish Repository"

### الخطوة 5: تفعيل GitHub Pages
1. اذهب إلى: https://github.com/alirheemattia-netizen/inventory-manager
2. اضغط على "Settings"
3. اختر "Pages" من القائمة الجانبية
4. اختر "Deploy from a branch"
5. اختر: `main` branch و `dist` folder
6. اضغط "Save"

### الخطوة 6: الحصول على الرابط
بعد دقيقة واحدة، سيظهر رابط مثل:
```
https://alirheemattia-netizen.github.io/inventory-manager
```

---

## الطريقة البديلة - استخدام سطر الأوامر

```bash
# 1. انتقل إلى مجلد المشروع
cd /home/ubuntu/inventory_manager_app

# 2. أضف الملفات
git add .

# 3. قم بـ Commit
git commit -m "Initial commit: Inventory Management App"

# 4. أضف الـ Remote
git remote add origin https://github.com/alirheemattia-netizen/inventory-manager.git

# 5. رفع المشروع
git push -u origin main

# 6. تفعيل GitHub Pages
# اذهب إلى: https://github.com/alirheemattia-netizen/inventory-manager/settings/pages
# واختر: main branch و dist folder
```

---

## الرابط النهائي

بعد تفعيل GitHub Pages، ستحصل على:
```
https://alirheemattia-netizen.github.io/inventory-manager
```

شارك هذا الرابط مع صديقك! ✅

---

## ملاحظات مهمة

- تأكد أن المستودع **Public** وليس Private
- تأكد أن مجلد `dist` موجود في المستودع
- قد تستغرق GitHub Pages دقيقة واحدة حتى تصبح جاهزة
- إذا لم يعمل، انتظر 5 دقائق وحاول مرة أخرى

