import { useState, useEffect } from 'react';

/**
 * Hook مخصص للتعامل مع Local Storage
 * يوفر تخزين محلي للبيانات مع مزامنة تلقائية
 */
export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((val: T) => T)) => void] {
  // State لتخزين القيمة
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      // الحصول على العنصر من localStorage
      const item = typeof window !== 'undefined' ? window.localStorage.getItem(key) : null;
      if (item) {
        return JSON.parse(item);
      }
      return initialValue;
    } catch (error) {
      console.error(`Error reading from localStorage for key "${key}":`, error);
      return initialValue;
    }
  });

  // دالة لتحديث القيمة وحفظها في localStorage
  const setValue = (value: T | ((val: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      }
    } catch (error) {
      console.error(`Error writing to localStorage for key "${key}":`, error);
    }
  };

  return [storedValue, setValue];
}

/**
 * Hook لحفظ البيانات المؤقتة للعمليات
 */
export function usePendingTransactions() {
  return useLocalStorage<Array<{
    categoryId: number;
    type: 'add' | 'sell';
    amount: number;
    description?: string;
    timestamp: number;
  }>>('pending_transactions', []);
}

/**
 * Hook لحفظ تفضيلات المستخدم
 */
export function useUserPreferences() {
  return useLocalStorage<{
    theme: 'light' | 'dark';
    language: string;
    defaultCategory?: number;
  }>('user_preferences', {
    theme: 'light',
    language: 'ar',
  });
}

/**
 * Hook لحفظ آخر تاريخ تم الوصول إليه
 */
export function useLastAccessedDate() {
  return useLocalStorage<string>('last_accessed_date', new Date().toISOString().split('T')[0]);
}
