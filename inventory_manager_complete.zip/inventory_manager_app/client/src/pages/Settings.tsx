import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Download, Upload, Trash2, RefreshCw } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Settings() {
  const { user, logout } = useAuth();
  const [isBackupDialogOpen, setIsBackupDialogOpen] = useState(false);
  const [isRestoreDialogOpen, setIsRestoreDialogOpen] = useState(false);

  // استعلامات
  const { data: categories = [] } = trpc.categories.list.useQuery();

  /**
   * إنشاء نسخة احتياطية من البيانات
   */
  const handleBackup = () => {
    try {
      const backupData = {
        timestamp: new Date().toISOString(),
        categories: categories,
        version: "1.0",
      };

      const element = document.createElement("a");
      element.setAttribute(
        "href",
        "data:application/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData, null, 2))
      );
      element.setAttribute("download", `backup-${new Date().getTime()}.json`);
      element.style.display = "none";
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

      toast.success("تم إنشاء النسخة الاحتياطية بنجاح");
      setIsBackupDialogOpen(false);
    } catch (error) {
      toast.error("فشل إنشاء النسخة الاحتياطية");
    }
  };

  /**
   * استعادة البيانات من نسخة احتياطية
   */
  const handleRestore = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const backupData = JSON.parse(e.target?.result as string);
        
        // التحقق من صحة البيانات
        if (!backupData.categories || !Array.isArray(backupData.categories)) {
          toast.error("ملف النسخة الاحتياطية غير صحيح");
          return;
        }

        // حفظ البيانات في localStorage
        localStorage.setItem("backup_data", JSON.stringify(backupData));
        
        toast.success("تم استعادة البيانات بنجاح. يرجى تحديث الصفحة.");
        setIsRestoreDialogOpen(false);
        
        // تحديث الصفحة بعد 2 ثانية
        setTimeout(() => window.location.reload(), 2000);
      } catch (error) {
        toast.error("فشل قراءة ملف النسخة الاحتياطية");
      }
    };
    reader.readAsText(file);
  };

  /**
   * حذف جميع البيانات
   */
  const handleClearAllData = () => {
    if (window.confirm("هل أنت متأكد من رغبتك في حذف جميع البيانات؟ هذا الإجراء لا يمكن التراجع عنه.")) {
      try {
        localStorage.clear();
        sessionStorage.clear();
        toast.success("تم حذف جميع البيانات");
        setTimeout(() => window.location.reload(), 1000);
      } catch (error) {
        toast.error("فشل حذف البيانات");
      }
    }
  };

  if (!user) {
    return <div className="p-8 text-center">يرجى تسجيل الدخول</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-8">
      <div className="max-w-4xl mx-auto">
        {/* الرأس */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">الإعدادات</h1>
          <p className="text-gray-600">إدارة حسابك والبيانات</p>
        </div>

        {/* معلومات الحساب */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>معلومات الحساب</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-gray-600">الاسم</p>
              <p className="text-lg font-medium">{user.name || "لم يتم تعيين"}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">البريد الإلكتروني</p>
              <p className="text-lg font-medium">{user.email || "لم يتم تعيين"}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">طريقة تسجيل الدخول</p>
              <p className="text-lg font-medium">{user.loginMethod || "Manus"}</p>
            </div>
            <Button variant="outline" onClick={logout}>
              تسجيل الخروج
            </Button>
          </CardContent>
        </Card>

        {/* إحصائيات البيانات */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>إحصائيات البيانات</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">عدد الفئات</p>
              <p className="text-3xl font-bold text-blue-600">{categories.length}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">إجمالي المخزون</p>
              <p className="text-3xl font-bold text-green-600">
                {categories.reduce((sum, cat) => sum + cat.currentBalance, 0)}
              </p>
            </div>
            <div className="bg-indigo-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">حجم التخزين</p>
              <p className="text-3xl font-bold text-indigo-600">
                {(JSON.stringify(categories).length / 1024).toFixed(2)} KB
              </p>
            </div>
          </CardContent>
        </Card>

        {/* النسخ الاحتياطي والاستعادة */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>النسخ الاحتياطي والاستعادة</CardTitle>
            <CardDescription>حفظ واستعادة بيانات التطبيق</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Dialog open={isBackupDialogOpen} onOpenChange={setIsBackupDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2 w-full">
                  <Download className="w-4 h-4" />
                  إنشاء نسخة احتياطية
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>إنشاء نسخة احتياطية</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <p className="text-gray-600">
                    سيتم تحميل ملف JSON يحتوي على جميع بيانات الفئات والعمليات. يمكنك استخدام هذا الملف لاستعادة البيانات لاحقًا.
                  </p>
                  <div className="flex gap-2">
                    <Button onClick={handleBackup} className="flex-1">
                      تحميل النسخة الاحتياطية
                    </Button>
                    <Button
                      onClick={() => setIsBackupDialogOpen(false)}
                      variant="outline"
                      className="flex-1"
                    >
                      إلغاء
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={isRestoreDialogOpen} onOpenChange={setIsRestoreDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-2 w-full">
                  <Upload className="w-4 h-4" />
                  استعادة من نسخة احتياطية
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>استعادة من نسخة احتياطية</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <p className="text-gray-600">
                    اختر ملف النسخة الاحتياطية لاستعادة البيانات. سيتم تحديث التطبيق تلقائيًا بعد الاستعادة.
                  </p>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleRestore}
                    className="block w-full text-sm text-gray-500
                      file:mr-4 file:py-2 file:px-4
                      file:rounded-md file:border-0
                      file:text-sm file:font-semibold
                      file:bg-indigo-50 file:text-indigo-700
                      hover:file:bg-indigo-100"
                  />
                  <Button
                    onClick={() => setIsRestoreDialogOpen(false)}
                    variant="outline"
                    className="w-full"
                  >
                    إلغاء
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        {/* حذف البيانات */}
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="text-red-600">منطقة الخطر</CardTitle>
            <CardDescription>إجراءات لا يمكن التراجع عنها</CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              variant="destructive"
              className="gap-2 w-full"
              onClick={handleClearAllData}
            >
              <Trash2 className="w-4 h-4" />
              حذف جميع البيانات
            </Button>
            <p className="text-sm text-red-600 mt-2">
              تحذير: هذا الإجراء سيحذف جميع البيانات بشكل دائم ولا يمكن التراجع عنه.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
