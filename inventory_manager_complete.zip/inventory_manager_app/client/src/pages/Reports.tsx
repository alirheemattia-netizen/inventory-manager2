import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

const CATEGORY_TYPES = {
  sim_lines: "خطوط SIM",
  currency: "العملات",
  visa: "الفيزا",
  electronic_cards: "بطاقات إلكترونية",
  device_asia: "جهاز آسيا",
  device_ether: "جهاز أثير",
};

export default function Reports() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().split("T")[0].substring(0, 7));

  // استعلامات
  const { data: categories = [] } = trpc.categories.list.useQuery();

  const { data: dailyReport } = trpc.reports.daily.useQuery(
    {
      categoryId: selectedCategory || 0,
      reportDate: selectedDate,
    },
    { enabled: !!selectedCategory }
  );

  const { data: monthlyReport } = trpc.reports.monthly.useQuery(
    {
      categoryId: selectedCategory || 0,
      reportMonth: selectedMonth,
    },
    { enabled: !!selectedCategory }
  );

  const { data: monthlyDetails = [] } = trpc.reports.monthlyDetails.useQuery(
    {
      categoryId: selectedCategory || 0,
      reportMonth: selectedMonth,
    },
    { enabled: !!selectedCategory }
  );

  if (!user) {
    return <div className="p-8 text-center">يرجى تسجيل الدخول</div>;
  }

  const currentCategory = categories.find((c) => c.id === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-8">
      <div className="max-w-6xl mx-auto">
        {/* الرأس */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">التقارير</h1>
          <p className="text-gray-600">عرض التقارير اليومية والشهرية</p>
        </div>

        {/* اختيار الفئة */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>اختر الفئة</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={selectedCategory?.toString() || ""} onValueChange={(v) => setSelectedCategory(parseInt(v))}>
              <SelectTrigger>
                <SelectValue placeholder="اختر الفئة" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id.toString()}>
                    {cat.name} - {CATEGORY_TYPES[cat.type as keyof typeof CATEGORY_TYPES]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {selectedCategory && currentCategory ? (
          <Tabs defaultValue="daily" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="daily">التقرير اليومي</TabsTrigger>
              <TabsTrigger value="monthly">التقرير الشهري</TabsTrigger>
            </TabsList>

            {/* التقرير اليومي */}
            <TabsContent value="daily" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>اختر التاريخ</CardTitle>
                </CardHeader>
                <CardContent>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  />
                </CardContent>
              </Card>

              {dailyReport ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card>
                    <CardHeader>
                      <CardDescription>الرصيد الافتتاحي</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold text-blue-600">{dailyReport.openingBalance}</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardDescription>إجمالي المضاف</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold text-green-600">{dailyReport.totalAdded}</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardDescription>إجمالي المباع</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold text-red-600">{dailyReport.totalSold}</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardDescription>الرصيد الختامي</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold text-indigo-600">{dailyReport.closingBalance}</p>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <p className="text-gray-600">لا توجد بيانات لهذا التاريخ</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* التقرير الشهري */}
            <TabsContent value="monthly" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>اختر الشهر</CardTitle>
                </CardHeader>
                <CardContent>
                  <input
                    type="month"
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  />
                </CardContent>
              </Card>

              {monthlyReport ? (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Card>
                      <CardHeader>
                        <CardDescription>الرصيد الافتتاحي</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-3xl font-bold text-blue-600">{monthlyReport.openingBalance}</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardDescription>إجمالي المضاف</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-3xl font-bold text-green-600">{monthlyReport.totalAdded}</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardDescription>إجمالي المباع</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-3xl font-bold text-red-600">{monthlyReport.totalSold}</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardDescription>الرصيد الختامي</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-3xl font-bold text-indigo-600">{monthlyReport.closingBalance}</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* تفاصيل الأيام */}
                  <Card>
                    <CardHeader>
                      <CardTitle>تفاصيل الأيام</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b">
                              <th className="text-right py-2 px-2">التاريخ</th>
                              <th className="text-right py-2 px-2">الافتتاح</th>
                              <th className="text-right py-2 px-2">المضاف</th>
                              <th className="text-right py-2 px-2">المباع</th>
                              <th className="text-right py-2 px-2">الختام</th>
                            </tr>
                          </thead>
                          <tbody>
                            {monthlyDetails.map((report) => (
                              <tr key={report.id} className="border-b hover:bg-gray-50">
                                <td className="py-2 px-2">{report.reportDate}</td>
                                <td className="py-2 px-2">{report.openingBalance}</td>
                                <td className="py-2 px-2 text-green-600">{report.totalAdded}</td>
                                <td className="py-2 px-2 text-red-600">{report.totalSold}</td>
                                <td className="py-2 px-2 font-semibold">{report.closingBalance}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <p className="text-gray-600">لا توجد بيانات لهذا الشهر</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        ) : (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-gray-600">يرجى اختيار فئة لعرض التقارير</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
