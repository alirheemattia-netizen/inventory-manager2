import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { Download, Printer } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const CATEGORY_TYPES = {
  sim_lines: "خطوط SIM",
  currency: "العملات",
  visa: "الفيزا",
  electronic_cards: "بطاقات إلكترونية",
  device_asia: "جهاز آسيا",
  device_ether: "جهاز أثير",
};

export default function AdvancedReports() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().split("T")[0].substring(0, 7));

  // استعلامات
  const { data: categories = [] } = trpc.categories.list.useQuery();
  const { data: monthlyReport } = trpc.reports.monthly.useQuery(
    {
      categoryId: selectedCategory || 0,
      reportMonth: selectedMonth,
    },
    { enabled: !!selectedCategory }
  );
  const { data: monthlyDetails = [] } = trpc.reports.monthlyDetails.useQuery(
    {
      categoryId: selectedCategory || 0,
      reportMonth: selectedMonth,
    },
    { enabled: !!selectedCategory }
  );

  const currentCategory = categories.find((c) => c.id === selectedCategory);

  /**
   * تصدير التقرير كـ CSV
   */
  const handleExportCSV = () => {
    if (!monthlyReport || !monthlyDetails.length) {
      toast.error("لا توجد بيانات للتصدير");
      return;
    }

    // إنشاء محتوى CSV
    let csv = "التقرير الشهري\n";
    csv += `الفئة: ${currentCategory?.name}\n`;
    csv += `الشهر: ${selectedMonth}\n\n`;
    csv += `الرصيد الافتتاحي,${monthlyReport.openingBalance}\n`;
    csv += `إجمالي المضاف,${monthlyReport.totalAdded}\n`;
    csv += `إجمالي المباع,${monthlyReport.totalSold}\n`;
    csv += `الرصيد الختامي,${monthlyReport.closingBalance}\n\n`;
    csv += "التاريخ,الافتتاح,المضاف,المباع,الختام\n";

    monthlyDetails.forEach((report) => {
      csv += `${report.reportDate},${report.openingBalance},${report.totalAdded},${report.totalSold},${report.closingBalance}\n`;
    });

    // تحميل الملف
    const element = document.createElement("a");
    element.setAttribute("href", "data:text/csv;charset=utf-8," + encodeURIComponent(csv));
    element.setAttribute("download", `report-${selectedMonth}.csv`);
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);

    toast.success("تم تصدير التقرير بنجاح");
  };

  /**
   * طباعة التقرير
   */
  const handlePrint = () => {
    if (!monthlyReport) {
      toast.error("لا توجد بيانات للطباعة");
      return;
    }

    const printWindow = window.open("", "", "height=600,width=800");
    if (!printWindow) {
      toast.error("فشل فتح نافذة الطباعة");
      return;
    }

    let html = `
      <html dir="rtl">
        <head>
          <title>التقرير الشهري</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { text-align: center; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: right; }
            th { background-color: #f2f2f2; }
            .summary { margin: 20px 0; }
          </style>
        </head>
        <body>
          <h1>التقرير الشهري</h1>
          <p><strong>الفئة:</strong> ${currentCategory?.name}</p>
          <p><strong>الشهر:</strong> ${selectedMonth}</p>
          
          <div class="summary">
            <h3>ملخص التقرير</h3>
            <p>الرصيد الافتتاحي: ${monthlyReport.openingBalance}</p>
            <p>إجمالي المضاف: ${monthlyReport.totalAdded}</p>
            <p>إجمالي المباع: ${monthlyReport.totalSold}</p>
            <p><strong>الرصيد الختامي: ${monthlyReport.closingBalance}</strong></p>
          </div>

          <h3>تفاصيل الأيام</h3>
          <table>
            <tr>
              <th>التاريخ</th>
              <th>الافتتاح</th>
              <th>المضاف</th>
              <th>المباع</th>
              <th>الختام</th>
            </tr>
    `;

    monthlyDetails.forEach((report) => {
      html += `
        <tr>
          <td>${report.reportDate}</td>
          <td>${report.openingBalance}</td>
          <td>${report.totalAdded}</td>
          <td>${report.totalSold}</td>
          <td>${report.closingBalance}</td>
        </tr>
      `;
    });

    html += `
          </table>
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.print();

    toast.success("تم إرسال التقرير للطباعة");
  };

  if (!user) {
    return <div className="p-8 text-center">يرجى تسجيل الدخول</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-8">
      <div className="max-w-6xl mx-auto">
        {/* الرأس */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">التقارير المتقدمة</h1>
          <p className="text-gray-600">تقارير شاملة مع خيارات التصدير والطباعة</p>
        </div>

        {/* اختيار الفئة والشهر */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>خيارات التقرير</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">الفئة</label>
                <Select value={selectedCategory?.toString() || ""} onValueChange={(v) => setSelectedCategory(parseInt(v))}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر الفئة" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id.toString()}>
                        {cat.name} - {CATEGORY_TYPES[cat.type as keyof typeof CATEGORY_TYPES]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">الشهر</label>
                <input
                  type="month"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
            </div>

            {/* أزرار التصدير والطباعة */}
            <div className="flex gap-4">
              <Button onClick={handleExportCSV} className="gap-2">
                <Download className="w-4 h-4" />
                تصدير CSV
              </Button>
              <Button onClick={handlePrint} variant="outline" className="gap-2">
                <Printer className="w-4 h-4" />
                طباعة
              </Button>
            </div>
          </CardContent>
        </Card>

        {selectedCategory && currentCategory && monthlyReport ? (
          <div className="space-y-6">
            {/* ملخص التقرير */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader>
                  <CardDescription>الرصيد الافتتاحي</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-blue-600">{monthlyReport.openingBalance}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardDescription>إجمالي المضاف</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-green-600">{monthlyReport.totalAdded}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardDescription>إجمالي المباع</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-red-600">{monthlyReport.totalSold}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardDescription>الرصيد الختامي</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-indigo-600">{monthlyReport.closingBalance}</p>
                </CardContent>
              </Card>
            </div>

            {/* جدول التفاصيل */}
            <Card>
              <CardHeader>
                <CardTitle>تفاصيل الأيام</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-gray-50">
                        <th className="text-right py-3 px-4 font-semibold">التاريخ</th>
                        <th className="text-right py-3 px-4 font-semibold">الافتتاح</th>
                        <th className="text-right py-3 px-4 font-semibold">المضاف</th>
                        <th className="text-right py-3 px-4 font-semibold">المباع</th>
                        <th className="text-right py-3 px-4 font-semibold">الختام</th>
                      </tr>
                    </thead>
                    <tbody>
                      {monthlyDetails.map((report) => (
                        <tr key={report.id} className="border-b hover:bg-gray-50 transition">
                          <td className="py-3 px-4">{report.reportDate}</td>
                          <td className="py-3 px-4">{report.openingBalance}</td>
                          <td className="py-3 px-4 text-green-600 font-medium">{report.totalAdded}</td>
                          <td className="py-3 px-4 text-red-600 font-medium">{report.totalSold}</td>
                          <td className="py-3 px-4 font-semibold text-indigo-600">{report.closingBalance}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* إحصائيات إضافية */}
            <Card>
              <CardHeader>
                <CardTitle>الإحصائيات</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-600">عدد العمليات</p>
                  <p className="text-2xl font-bold">{monthlyReport.totalTransactions}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">متوسط العملية</p>
                  <p className="text-2xl font-bold">
                    {monthlyReport.totalTransactions > 0
                      ? Math.round((monthlyReport.totalAdded + monthlyReport.totalSold) / monthlyReport.totalTransactions)
                      : 0}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">صافي التغيير</p>
                  <p className={`text-2xl font-bold ${monthlyReport.closingBalance - monthlyReport.openingBalance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {monthlyReport.closingBalance - monthlyReport.openingBalance}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-gray-600">يرجى اختيار فئة وشهر لعرض التقارير</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
