import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { Plus, TrendingDown, TrendingUp } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const CATEGORY_TYPES = {
  sim_lines: "خطوط SIM",
  currency: "العملات",
  visa: "الفيزا",
  electronic_cards: "بطاقات إلكترونية",
  device_asia: "جهاز آسيا",
  device_ether: "جهاز أثير",
};

export default function Dashboard() {
  const { user } = useAuth();
  const [isAddCategoryOpen, setIsAddCategoryOpen] = useState(false);
  const [isAddTransactionOpen, setIsAddTransactionOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);

  // استعلامات
  const { data: categories = [], isLoading: categoriesLoading, refetch: refetchCategories } = trpc.categories.list.useQuery();

  // الطفرات
  const createCategoryMutation = trpc.categories.create.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء الفئة بنجاح");
      setIsAddCategoryOpen(false);
      refetchCategories();
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ");
    },
  });

  const addTransactionMutation = trpc.transactions.add.useMutation({
    onSuccess: () => {
      toast.success("تم تسجيل العملية بنجاح");
      setIsAddTransactionOpen(false);
      refetchCategories();
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ");
    },
  });

  const handleCreateCategory = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createCategoryMutation.mutate({
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      type: formData.get("type") as any,
      initialBalance: parseInt(formData.get("initialBalance") as string) || 0,
    });
  };

  const handleAddTransaction = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedCategory) {
      toast.error("يرجى اختيار فئة");
      return;
    }

    const formData = new FormData(e.currentTarget);
    
    addTransactionMutation.mutate({
      categoryId: selectedCategory,
      type: formData.get("type") as "add" | "sell",
      amount: parseInt(formData.get("amount") as string),
      description: formData.get("description") as string,
    });
  };

  if (!user) {
    return <div className="p-8 text-center">يرجى تسجيل الدخول</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* الرأس */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">لوحة التحكم</h1>
          <p className="text-gray-600">مرحبا {user.name || "المستخدم"}</p>
        </div>

        {/* أزرار الإجراءات */}
        <div className="flex gap-4 mb-8">
          <Dialog open={isAddCategoryOpen} onOpenChange={setIsAddCategoryOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                إضافة فئة جديدة
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>إضافة فئة جديدة</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateCategory} className="space-y-4">
                <div>
                  <Label htmlFor="name">اسم الفئة</Label>
                  <Input id="name" name="name" placeholder="مثل: دولار أمريكي" required />
                </div>
                <div>
                  <Label htmlFor="description">الوصف</Label>
                  <Input id="description" name="description" placeholder="وصف اختياري" />
                </div>
                <div>
                  <Label htmlFor="type">النوع</Label>
                  <Select name="type" required>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر النوع" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(CATEGORY_TYPES).map(([key, label]) => (
                        <SelectItem key={key} value={key}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="initialBalance">الرصيد الأولي</Label>
                  <Input
                    id="initialBalance"
                    name="initialBalance"
                    type="number"
                    placeholder="0"
                    defaultValue="0"
                  />
                </div>
                <Button type="submit" className="w-full" disabled={createCategoryMutation.isPending}>
                  {createCategoryMutation.isPending ? "جاري الإنشاء..." : "إنشاء"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <Dialog open={isAddTransactionOpen} onOpenChange={setIsAddTransactionOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Plus className="w-4 h-4" />
                تسجيل عملية
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>تسجيل عملية جديدة</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddTransaction} className="space-y-4">
                <div>
                  <Label htmlFor="category">الفئة</Label>
                  <Select value={selectedCategory?.toString() || ""} onValueChange={(v) => setSelectedCategory(parseInt(v))}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر الفئة" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.id.toString()}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="type">نوع العملية</Label>
                  <Select name="type" required>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر النوع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="add">إضافة</SelectItem>
                      <SelectItem value="sell">بيع</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="amount">المبلغ</Label>
                  <Input
                    id="amount"
                    name="amount"
                    type="number"
                    placeholder="0"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">ملاحظات</Label>
                  <Input id="description" name="description" placeholder="ملاحظات اختيارية" />
                </div>
                <Button type="submit" className="w-full" disabled={addTransactionMutation.isPending}>
                  {addTransactionMutation.isPending ? "جاري التسجيل..." : "تسجيل"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* الفئات */}
        {categoriesLoading ? (
          <div className="text-center py-8">جاري التحميل...</div>
        ) : categories.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-gray-600">لم تقم بإنشاء أي فئات حتى الآن</p>
              <p className="text-sm text-gray-500 mt-2">ابدأ بإضافة فئة جديدة</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <Card key={category.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">{category.name}</CardTitle>
                  <CardDescription>{CATEGORY_TYPES[category.type as keyof typeof CATEGORY_TYPES]}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">الرصيد الحالي</p>
                      <p className="text-3xl font-bold text-indigo-600">{category.currentBalance}</p>
                    </div>
                    {category.description && (
                      <p className="text-sm text-gray-600">{category.description}</p>
                    )}
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 gap-1"
                        onClick={() => {
                          setSelectedCategory(category.id);
                          setIsAddTransactionOpen(true);
                        }}
                      >
                        <TrendingUp className="w-4 h-4" />
                        إضافة
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 gap-1"
                        onClick={() => {
                          setSelectedCategory(category.id);
                          setIsAddTransactionOpen(true);
                        }}
                      >
                        <TrendingDown className="w-4 h-4" />
                        بيع
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
