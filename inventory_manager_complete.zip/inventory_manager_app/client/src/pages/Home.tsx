import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { Link } from "wouter";
import { BarChart3, FileText, Plus, Settings as SettingsIcon } from "lucide-react";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
        {/* الرأس */}
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <img src={APP_LOGO} alt={APP_TITLE} className="w-8 h-8" />
              <h1 className="text-xl font-bold text-gray-900">{APP_TITLE}</h1>
            </div>
            <a href={getLoginUrl()} className="text-indigo-600 hover:text-indigo-700 font-medium">
              تسجيل الدخول
            </a>
          </div>
        </header>

        {/* المحتوى الرئيسي */}
        <main className="max-w-7xl mx-auto px-4 py-16">
          <div className="text-center mb-12">
            <h2 className="text-5xl font-bold text-gray-900 mb-4">تطبيق إدارة المخزون والعمليات المالية</h2>
            <p className="text-xl text-gray-600 mb-8">
              إدارة سهلة وفعالة لمخزونك المالي والسلعي مع تقارير يومية وشهرية
            </p>
            <a href={getLoginUrl()}>
              <Button size="lg" className="gap-2">
                ابدأ الآن
              </Button>
            </a>
          </div>

          {/* المميزات */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <Plus className="w-8 h-8 text-indigo-600 mb-2" />
                <CardTitle>إدارة سهلة</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">واجهة بسيطة وسهلة الاستخدام لإضافة وتسجيل جميع العمليات</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <BarChart3 className="w-8 h-8 text-green-600 mb-2" />
                <CardTitle>عمليات حسابية تلقائية</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">حساب تلقائي للأرصدة والعمليات دون الحاجة لحسابات يدوية</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <FileText className="w-8 h-8 text-blue-600 mb-2" />
                <CardTitle>تقارير شاملة</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">تقارير يومية وشهرية مفصلة لكل صنف من الأصناف</p>
              </CardContent>
            </Card>
          </div>

          {/* الأصناف المدعومة */}
          <div className="mt-16">
            <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">الأصناف المدعومة</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                "خطوط SIM",
                "العملات (دولار، سعودي، بحريني، كويتي)",
                "الفيزا",
                "بطاقات إلكترونية",
                "جهاز آسيا",
                "جهاز أثير",
              ].map((item, idx) => (
                <Card key={idx}>
                  <CardContent className="pt-6">
                    <p className="text-gray-700">{item}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* الرأس */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <img src={APP_LOGO} alt={APP_TITLE} className="w-8 h-8" />
            <h1 className="text-xl font-bold text-gray-900">{APP_TITLE}</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-gray-600">مرحبا {user?.name}</span>
            <Button variant="outline" onClick={logout}>
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </header>

      {/* المحتوى */}
      <main className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">مرحبا بك في تطبيق إدارة المخزون</h2>
          <p className="text-lg text-gray-600 mb-8">اختر أحد الخيارات أدناه للبدء</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
          <Link href="/dashboard">
            <Button size="lg" className="w-full h-32 text-lg gap-2 flex flex-col">
              <BarChart3 className="w-8 h-8" />
              لوحة التحكم
            </Button>
          </Link>

          <Link href="/reports">
            <Button size="lg" variant="outline" className="w-full h-32 text-lg gap-2 flex flex-col">
              <FileText className="w-8 h-8" />
              التقارير
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto mt-4">
          <Link href="/advanced-reports">
            <Button size="lg" variant="outline" className="w-full h-24 text-base gap-2 flex flex-col">
              <FileText className="w-6 h-6" />
              التقارير المتقدمة
            </Button>
          </Link>

          <Link href="/settings">
            <Button size="lg" variant="outline" className="w-full h-24 text-base gap-2 flex flex-col">
              <BarChart3 className="w-6 h-6" />
              الإعدادات
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
