import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  createCategory,
  getUserCategories,
  getCategory,
  addTransaction,
  getCategoryTransactions,
  getDailyReport,
  upsertDailyReport,
  getMonthlyReport,
  upsertMonthlyReport,
  getMonthDailyReports,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // الفئات (الأصناف)
  categories: router({
    /**
     * إنشاء فئة جديدة
     */
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1, "اسم الفئة مطلوب"),
          description: z.string().optional(),
          type: z.enum([
            "sim_lines",
            "currency",
            "visa",
            "electronic_cards",
            "device_asia",
            "device_ether",
          ]),
          initialBalance: z.number().int().default(0),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Not authenticated");
        return await createCategory(ctx.user.id, input);
      }),

    /**
     * الحصول على جميع الفئات للمستخدم الحالي
     */
    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new Error("Not authenticated");
      return await getUserCategories(ctx.user.id);
    }),

    /**
     * الحصول على فئة واحدة
     */
    get: protectedProcedure
      .input(z.object({ categoryId: z.number().int() }))
      .query(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Not authenticated");
        return await getCategory(input.categoryId, ctx.user.id);
      }),
  }),

  // العمليات (المعاملات)
  transactions: router({
    /**
     * إضافة عملية جديدة (إضافة أو بيع)
     */
    add: protectedProcedure
      .input(
        z.object({
          categoryId: z.number().int(),
          type: z.enum(["add", "sell"]),
          amount: z.number().int().positive("المبلغ يجب أن يكون موجب"),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Not authenticated");
        const result = await addTransaction(ctx.user.id, input);
        
        // تحديث التقارير اليومية والشهرية
        const now = new Date();
        const reportDate = now.toISOString().split("T")[0];
        const reportMonth = reportDate.substring(0, 7);
        
        await upsertDailyReport(ctx.user.id, input.categoryId, reportDate);
        await upsertMonthlyReport(ctx.user.id, input.categoryId, reportMonth);
        
        return result;
      }),

    /**
     * الحصول على العمليات لفئة معينة
     */
    list: protectedProcedure
      .input(
        z.object({
          categoryId: z.number().int(),
          limit: z.number().int().default(100),
        })
      )
      .query(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Not authenticated");
        return await getCategoryTransactions(input.categoryId, ctx.user.id, input.limit);
      }),
  }),

  // التقارير
  reports: router({
    /**
     * الحصول على التقرير اليومي
     */
    daily: protectedProcedure
      .input(
        z.object({
          categoryId: z.number().int(),
          reportDate: z.string(), // YYYY-MM-DD
        })
      )
      .query(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Not authenticated");
        return await getDailyReport(ctx.user.id, input.categoryId, input.reportDate);
      }),

    /**
     * الحصول على التقرير الشهري
     */
    monthly: protectedProcedure
      .input(
        z.object({
          categoryId: z.number().int(),
          reportMonth: z.string(), // YYYY-MM
        })
      )
      .query(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Not authenticated");
        return await getMonthlyReport(ctx.user.id, input.categoryId, input.reportMonth);
      }),

    /**
     * الحصول على جميع التقارير اليومية لشهر معين
     */
    monthlyDetails: protectedProcedure
      .input(
        z.object({
          categoryId: z.number().int(),
          reportMonth: z.string(), // YYYY-MM
        })
      )
      .query(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Not authenticated");
        return await getMonthDailyReports(ctx.user.id, input.categoryId, input.reportMonth);
      }),
  }),
});

export type AppRouter = typeof appRouter;
