import { eq, and, gte, lte, sum, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, categories, transactions, dailyReports, monthlyReports } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * إنشاء فئة جديدة (صنف)
 */
export async function createCategory(userId: number, data: {
  name: string;
  description?: string;
  type: string;
  initialBalance?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(categories).values({
    userId,
    name: data.name,
    description: data.description,
    type: data.type as any,
    initialBalance: data.initialBalance || 0,
    currentBalance: data.initialBalance || 0,
  });

  return result;
}

/**
 * الحصول على جميع الفئات لمستخدم معين
 */
export async function getUserCategories(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(categories).where(eq(categories.userId, userId));
}

/**
 * الحصول على فئة واحدة
 */
export async function getCategory(categoryId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(categories).where(
    and(eq(categories.id, categoryId), eq(categories.userId, userId))
  );

  return result.length > 0 ? result[0] : null;
}

/**
 * إضافة عملية (إضافة أو بيع)
 */
export async function addTransaction(userId: number, data: {
  categoryId: number;
  type: "add" | "sell";
  amount: number;
  description?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // الحصول على الفئة الحالية
  const category = await getCategory(data.categoryId, userId);
  if (!category) throw new Error("Category not found");

  // حساب الرصيد الجديد
  const balanceBefore = category.currentBalance;
  const balanceAfter = data.type === "add" 
    ? balanceBefore + data.amount 
    : balanceBefore - data.amount;

  // التحقق من عدم الذهاب إلى أرقام سالبة في حالة البيع
  if (balanceAfter < 0) {
    throw new Error("Insufficient balance");
  }

  // تسجيل العملية
  const transactionResult = await db.insert(transactions).values({
    userId,
    categoryId: data.categoryId,
    type: data.type,
    amount: data.amount,
    description: data.description,
    balanceBefore,
    balanceAfter,
    transactionDate: new Date(),
  });

  // تحديث الرصيد الحالي في الفئة
  await db.update(categories)
    .set({ currentBalance: balanceAfter })
    .where(eq(categories.id, data.categoryId));

  return { transactionResult, balanceAfter };
}

/**
 * الحصول على العمليات لفئة معينة
 */
export async function getCategoryTransactions(categoryId: number, userId: number, limit = 100) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select()
    .from(transactions)
    .where(and(eq(transactions.categoryId, categoryId), eq(transactions.userId, userId)))
    .orderBy(desc(transactions.createdAt))
    .limit(limit);
}

/**
 * الحصول على التقرير اليومي لفئة معينة
 */
export async function getDailyReport(userId: number, categoryId: number, reportDate: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(dailyReports).where(
    and(
      eq(dailyReports.userId, userId),
      eq(dailyReports.categoryId, categoryId),
      eq(dailyReports.reportDate, reportDate)
    )
  );

  return result.length > 0 ? result[0] : null;
}

/**
 * إنشاء أو تحديث التقرير اليومي
 */
export async function upsertDailyReport(userId: number, categoryId: number, reportDate: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // الحصول على جميع العمليات لهذا اليوم
  const startDate = new Date(`${reportDate}T00:00:00Z`);
  const endDate = new Date(`${reportDate}T23:59:59Z`);

  const dayTransactions = await db.select()
    .from(transactions)
    .where(
      and(
        eq(transactions.userId, userId),
        eq(transactions.categoryId, categoryId),
        gte(transactions.transactionDate, startDate),
        lte(transactions.transactionDate, endDate)
      )
    );

  // حساب الإجماليات
  let totalAdded = 0;
  let totalSold = 0;
  let openingBalance = 0;
  let closingBalance = 0;

  if (dayTransactions.length > 0) {
    openingBalance = dayTransactions[0].balanceBefore;
    closingBalance = dayTransactions[dayTransactions.length - 1].balanceAfter;

    dayTransactions.forEach(tx => {
      if (tx.type === "add") {
        totalAdded += tx.amount;
      } else {
        totalSold += tx.amount;
      }
    });
  } else {
    // إذا لم تكن هناك عمليات، احصل على الرصيد من الفئة
    const category = await getCategory(categoryId, userId);
    if (category) {
      openingBalance = category.currentBalance;
      closingBalance = category.currentBalance;
    }
  }

  // البحث عن تقرير موجود
  const existingReport = await getDailyReport(userId, categoryId, reportDate);

  if (existingReport) {
    // تحديث التقرير الموجود
    await db.update(dailyReports)
      .set({
        openingBalance,
        totalAdded,
        totalSold,
        closingBalance,
      })
      .where(eq(dailyReports.id, existingReport.id));
  } else {
    // إنشاء تقرير جديد
    await db.insert(dailyReports).values({
      userId,
      categoryId,
      reportDate,
      openingBalance,
      totalAdded,
      totalSold,
      closingBalance,
    });
  }
}

/**
 * الحصول على التقرير الشهري لفئة معينة
 */
export async function getMonthlyReport(userId: number, categoryId: number, reportMonth: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(monthlyReports).where(
    and(
      eq(monthlyReports.userId, userId),
      eq(monthlyReports.categoryId, categoryId),
      eq(monthlyReports.reportMonth, reportMonth)
    )
  );

  return result.length > 0 ? result[0] : null;
}

/**
 * إنشاء أو تحديث التقرير الشهري
 */
export async function upsertMonthlyReport(userId: number, categoryId: number, reportMonth: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // الحصول على جميع العمليات لهذا الشهر
  const [year, month] = reportMonth.split("-");
  const startDate = new Date(`${year}-${month}-01T00:00:00Z`);
  const endDate = new Date(startDate);
  endDate.setMonth(endDate.getMonth() + 1);

  const monthTransactions = await db.select()
    .from(transactions)
    .where(
      and(
        eq(transactions.userId, userId),
        eq(transactions.categoryId, categoryId),
        gte(transactions.transactionDate, startDate),
        lte(transactions.transactionDate, endDate)
      )
    );

  // حساب الإجماليات
  let totalAdded = 0;
  let totalSold = 0;
  let openingBalance = 0;
  let closingBalance = 0;

  if (monthTransactions.length > 0) {
    openingBalance = monthTransactions[0].balanceBefore;
    closingBalance = monthTransactions[monthTransactions.length - 1].balanceAfter;

    monthTransactions.forEach(tx => {
      if (tx.type === "add") {
        totalAdded += tx.amount;
      } else {
        totalSold += tx.amount;
      }
    });
  } else {
    // إذا لم تكن هناك عمليات، احصل على الرصيد من الفئة
    const category = await getCategory(categoryId, userId);
    if (category) {
      openingBalance = category.currentBalance;
      closingBalance = category.currentBalance;
    }
  }

  // البحث عن تقرير موجود
  const existingReport = await getMonthlyReport(userId, categoryId, reportMonth);

  if (existingReport) {
    // تحديث التقرير الموجود
    await db.update(monthlyReports)
      .set({
        openingBalance,
        totalAdded,
        totalSold,
        closingBalance,
        totalTransactions: monthTransactions.length,
      })
      .where(eq(monthlyReports.id, existingReport.id));
  } else {
    // إنشاء تقرير جديد
    await db.insert(monthlyReports).values({
      userId,
      categoryId,
      reportMonth,
      openingBalance,
      totalAdded,
      totalSold,
      closingBalance,
      totalTransactions: monthTransactions.length,
    });
  }
}

/**
 * الحصول على جميع التقارير اليومية لشهر معين
 */
export async function getMonthDailyReports(userId: number, categoryId: number, reportMonth: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select()
    .from(dailyReports)
    .where(
      and(
        eq(dailyReports.userId, userId),
        eq(dailyReports.categoryId, categoryId),
        gte(dailyReports.reportDate, `${reportMonth}-01`),
        lte(dailyReports.reportDate, `${reportMonth}-31`)
      )
    )
    .orderBy(desc(dailyReports.reportDate));
}
