import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

/**
 * جدول المستخدمين - يدعم المصادقة والتفويض
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * جدول الأصناف (الفئات)
 * يحتوي على جميع أنواع المنتجات والعملات والخدمات
 */
export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(), // مثل: "خطوط SIM"، "دولار"، "فيزا"، إلخ
  description: text("description"),
  type: mysqlEnum("type", [
    "sim_lines",
    "currency",
    "visa",
    "electronic_cards",
    "device_asia",
    "device_ether"
  ]).notNull(),
  initialBalance: int("initialBalance").default(0).notNull(), // الرصيد الأولي
  currentBalance: int("currentBalance").default(0).notNull(), // الرصيد الحالي
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;

/**
 * جدول العمليات (المعاملات)
 * يسجل جميع عمليات الإضافة والبيع
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  categoryId: int("categoryId").notNull(),
  type: mysqlEnum("type", ["add", "sell"]).notNull(), // إضافة أو بيع
  amount: int("amount").notNull(), // المبلغ أو الكمية
  description: text("description"), // ملاحظات إضافية
  balanceBefore: int("balanceBefore").notNull(), // الرصيد قبل العملية
  balanceAfter: int("balanceAfter").notNull(), // الرصيد بعد العملية
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  transactionDate: timestamp("transactionDate").defaultNow().notNull(), // تاريخ العملية
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * جدول التقارير اليومية
 * يحتفظ بملخص العمليات لكل يوم
 */
export const dailyReports = mysqlTable("dailyReports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  categoryId: int("categoryId").notNull(),
  reportDate: varchar("reportDate", { length: 10 }).notNull(), // YYYY-MM-DD
  openingBalance: int("openingBalance").notNull(), // الرصيد الافتتاحي
  totalAdded: int("totalAdded").default(0).notNull(), // إجمالي المضاف
  totalSold: int("totalSold").default(0).notNull(), // إجمالي المباع
  closingBalance: int("closingBalance").notNull(), // الرصيد الختامي
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DailyReport = typeof dailyReports.$inferSelect;
export type InsertDailyReport = typeof dailyReports.$inferInsert;

/**
 * جدول التقارير الشهرية
 * يحتفظ بملخص العمليات لكل شهر
 */
export const monthlyReports = mysqlTable("monthlyReports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  categoryId: int("categoryId").notNull(),
  reportMonth: varchar("reportMonth", { length: 7 }).notNull(), // YYYY-MM
  openingBalance: int("openingBalance").notNull(), // الرصيد الافتتاحي
  totalAdded: int("totalAdded").default(0).notNull(), // إجمالي المضاف
  totalSold: int("totalSold").default(0).notNull(), // إجمالي المباع
  closingBalance: int("closingBalance").notNull(), // الرصيد الختامي
  totalTransactions: int("totalTransactions").default(0).notNull(), // عدد العمليات
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MonthlyReport = typeof monthlyReports.$inferSelect;
export type InsertMonthlyReport = typeof monthlyReports.$inferInsert;
